"""BioPipe-CLI llm module."""
