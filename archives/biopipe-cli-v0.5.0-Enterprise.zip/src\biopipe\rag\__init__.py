"""BioPipe-CLI rag module."""
